from .mdict import IndexBuilder as MdxBuilder
from .pystardict import Dictionary as StardictBuilder
